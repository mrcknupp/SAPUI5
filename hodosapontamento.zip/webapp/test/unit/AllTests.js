sap.ui.define([
	"hodos/hodosapont/ZHODOSAPONT/test/unit/controller/Main.controller"
], function () {
	"use strict";
});