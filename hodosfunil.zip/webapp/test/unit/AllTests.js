sap.ui.define([
	"hodos/hodosfunil/test/unit/controller/Main.controller"
], function () {
	"use strict";
});