sap.ui.define([
	"hodos/hodosconversao/test/unit/controller/Main.controller"
], function () {
	"use strict";
});