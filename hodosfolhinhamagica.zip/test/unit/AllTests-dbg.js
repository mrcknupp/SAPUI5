sap.ui.define([
	"hodosovp/FolhaMagica/test/unit/controller/Main.controller"
], function () {
	"use strict";
});