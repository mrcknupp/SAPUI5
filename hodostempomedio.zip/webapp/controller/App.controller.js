sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	'sap/viz/ui5/format/ChartFormatter'
], function (Controller, JSONModel, History, ChartFormatter) {
	"use strict";

	return Controller.extend("hodos.hodostempomedio.controller.App", {
		onInit: function () {

		}
	});
});