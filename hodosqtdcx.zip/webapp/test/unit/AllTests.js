sap.ui.define([
	"hodosovp/Qtdcx/test/unit/controller/Main.controller"
], function () {
	"use strict";
});