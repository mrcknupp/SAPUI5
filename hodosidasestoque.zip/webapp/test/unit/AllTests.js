sap.ui.define([
	"hodosovp/Estoque/test/unit/controller/Main.controller"
], function () {
	"use strict";
});