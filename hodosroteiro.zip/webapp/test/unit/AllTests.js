sap.ui.define([
	"hodos/hodosroteiro/test/unit/controller/Main.controller"
], function () {
	"use strict";
});